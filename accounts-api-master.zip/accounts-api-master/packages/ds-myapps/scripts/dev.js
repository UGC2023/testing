const { bootstrap } = require('@api/tools')
const ds = require('../')

bootstrap(ds)
